"""Hierarchic data-viewing widget for wxPython"""
__version__ = '1.0.5'
