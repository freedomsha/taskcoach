I18n_core: Initialize internationalization for your app

I18n_core is a wrapper over the default locale stdlib module.
It provides a way to load global app translations, as well as translations from component libraries.

The library also has a gui module to assist with translation support for WxPython.
