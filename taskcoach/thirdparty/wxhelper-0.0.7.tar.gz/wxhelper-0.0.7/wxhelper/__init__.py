from .core import Bot

version = "0.0.7"
